# AXA Common Error Handler

## What is this asset for? ##
This is a reusable asset for common APIKIT and Global Errors for internal APIs.

# Prerequisites #

AXA Anypoint exchange access

# Installation #
1. Import dependency in Mule application:
		<dependency>
			<groupId>331792da-b10c-491b-8881-10cd31aa171d</groupId>
			<artifactId>common-axa-error-handler</artifactId>
			<version>1.0.0-SNAPSHOT</version>
			<classifier>mule-plugin</classifier>
		</dependency>

2. In global-config.xml, import the following files:
	<import doc:name="Import" doc:id="9a077495-006f-4786-ac89-9c40227a1d9e" 
	file="common-global-error-handler.xml" />
	<import doc:name="Import" doc:id="1a66e2ad-e878-4943-bb77-64da9b14eef9"
	file="common-apikit-error-handler.xml" />
	<import doc:name="Import" doc:id="709bd9af-02b1-41b3-827b-a25dbecfed51"
	file="system/messaging-sys-api-flow.xml" />

3. Reference the error handlers as necessary:
	- common-apikit-Error_Handler should be referenced in APIKIT main flow.
	- common-global-Error_Handler should be configured as the default error handler.
	<configuration doc:name="Configuration" doc:id="e8c032d6-3c38-4fdc-8d1c-c047aca9c21a"
	defaultErrorHandler-ref="common-global-Error_Handler" />

4. Override config properties as necessary. Configurable properties are as as follows:
	- messaging-sys-api properties
	- error message/description properties

5. Run Mule application. 

6. For more information, see api documentation at https://anypoint.mulesoft.com/exchange/331792da-b10c-491b-8881-10cd31aa171d/common-axa-error-handler/minor/1.0/.

