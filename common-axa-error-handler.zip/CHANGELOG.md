# Changelog

All notable changes to this asset will be documented in this file.

## [1.0.0] - 2023-07-03 ##
### Added 
- Initial version.